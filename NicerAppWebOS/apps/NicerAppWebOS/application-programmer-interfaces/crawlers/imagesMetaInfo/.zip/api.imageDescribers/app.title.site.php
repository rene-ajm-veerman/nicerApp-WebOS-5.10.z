NicerApp Image Describer Engine test results
