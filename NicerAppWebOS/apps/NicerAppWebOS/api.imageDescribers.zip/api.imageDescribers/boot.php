<?php 
require_once(realpath(dirname(__FILE__).'/../../..').'/boot.php'); // nicerapp boot.php
require_once(dirname(__FILE__).'/class.imageDescriberEngine.php');

require_once(dirname(__FILE__).'/interface.imageDescriberEngine_plugin.php');
require_once(dirname(__FILE__).'/class.imageDescriberEngine_plugin_clarifaiDotCom.php');

?>
